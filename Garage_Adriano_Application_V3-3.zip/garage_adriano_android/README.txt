GARAGE ADRIANO — MON SUIVI V3

Projet Android Studio + version PWA.
L'icône utilise le logo Garage Adriano fourni.
Fonctions: accueil, calendrier, clients, véhicules (modèle/plaque), devis et relances.

APK: ouvrir le dossier dans Android Studio puis Build > Build APK(s).
Le prototype stocke ses données localement. Les notifications natives et la sauvegarde en ligne seront ajoutées dans une prochaine étape.
